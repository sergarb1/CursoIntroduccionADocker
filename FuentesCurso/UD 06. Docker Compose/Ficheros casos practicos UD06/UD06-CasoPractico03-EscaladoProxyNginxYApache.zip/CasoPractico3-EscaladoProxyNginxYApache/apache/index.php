<html>
	<body>
		<h1>Servido por: Servidor con IP <?php echo $_SERVER['SERVER_ADDR'];?> 
		y hostname <?php echo gethostname(); ?></h1>
	</body>
</html>
